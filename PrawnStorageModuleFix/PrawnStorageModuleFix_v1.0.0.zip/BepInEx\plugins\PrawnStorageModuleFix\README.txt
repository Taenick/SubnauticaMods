PrawnStorageModuleFix
=====================

Fixes the Prawn Suit (Exosuit) storage module stacking bug in Subnautica.

In the vanilla game, equipping multiple Vehicle Storage Modules in the Prawn Suit
does not increase storage capacity beyond the first module. This mod fixes that so
each additional storage module correctly adds another row of storage slots.

Note: The base Prawn Suit storage is adjusted from 16 slots (4x4) to 18 slots (6x3)
so that every storage module adds a clean row of 6 slots to a uniform 6-wide grid.

Storage Capacity
----------------
  0 modules: 18 slots (6x3)
  1 module:  24 slots (6x4)
  2 modules: 30 slots (6x5)
  3 modules: 36 slots (6x6)
  4 modules: 42 slots (6x7)

Requirements
------------
  - Subnautica
  - BepInEx 5.4.21

Installation
------------
  1. Install BepInEx 5 for Subnautica if you haven't already.
  2. Copy PrawnStorageModuleFix.dll into:
     Subnautica\BepInEx\plugins\PrawnStorageModuleFix\

Uninstallation
--------------
  Delete the PrawnStorageModuleFix folder from BepInEx\plugins\.

Compatibility
-------------
  - Safe to install on existing saves.
  - Items in storage are not affected when adding or removing the mod.
